package com.bookshop.bookshop.command;

//OrderCommand is the base interface for the Command Pattern.
public interface OrderCommand {
    void execute();
}

